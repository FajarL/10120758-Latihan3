package com.example.a10120758Latihan3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a10120758latihan3.R

class HaiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hai)
    }
}